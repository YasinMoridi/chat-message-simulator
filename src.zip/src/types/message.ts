export type MessageType = "text" | "system" | "image"
export type MessageStatus = "sent" | "delivered" | "read"

export interface Message {
  id: string
  senderId: string
  content: string
  imageUrl?: string
  timestamp: string
  type: MessageType
  status: MessageStatus
  isHidden?: boolean
  /**
   * How long (in milliseconds) this message should wait after the previous
   * visible message before it appears when played back.
   */
  delayMs?: number
  /**
   * How long (in milliseconds) the OS notification banner waits after this
   * message appears before it slides in. Lets the notification feel like a
   * separate, slightly-later event instead of popping in at the exact same
   * instant as the chat bubble. Falls back to DEFAULT_NOTIFICATION_DELAY_MS
   * when unset.
   */
  notificationDelayMs?: number
  /**
   * When enabled, the OS notification banner for this message shows a
   * different name/app/avatar than the real sender - e.g. simulate a
   * notification arriving from an unrelated app or contact while this chat
   * message is on screen. Only affects the notification banner; the chat
   * bubble itself always shows the real sender.
   */
  notificationOverride?: {
    enabled: boolean
    senderName?: string
    appName?: string
    avatarUrl?: string
  }
}

/** Default delay (ms) before the OS notification banner appears after a message lands. */
export const DEFAULT_NOTIFICATION_DELAY_MS = 700

/** Default delay (ms) applied to a message when none is set. */
export const DEFAULT_MESSAGE_DELAY_MS = 1200
